package com.praveen.kafka.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Incoming {
    @JsonProperty("source-type")
    private String sourceType;

    @JsonProperty("source-address")
    private String sourceAddress;

    private List<Message> message;

}
