package com.praveen.kafka.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Property {
    @JsonProperty("attribute-name")
    private String attributeName;

    @JsonProperty("json-type")
    private String jsonType;

    @JsonProperty("json-format")
    private String jsonFormat;

    @JsonProperty("stop-processing-if-null-or-empty")
    private String stopProcessingIfNullOrEmpty;
}
