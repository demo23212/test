package com.praveen.kafka.model;

import com.fasterxml.jackson.annotation.JsonAnySetter;
import lombok.ToString;

import java.util.HashMap;
import java.util.Map;

public class RootConfig {
    private Map<String, GenericServiceConfig> services = new HashMap<>();

    @JsonAnySetter
    public void addService(String name, GenericServiceConfig config) {
        services.put(name, config);
    }

    public Map<String, GenericServiceConfig> getServices() {
        return services;
    }
}
