package com.praveen.kafka.listener;

import com.praveen.kafka.config.JsonConfigLoader;
import com.praveen.kafka.model.GenericServiceConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class KafkaListener {

    @Autowired
    private JsonConfigLoader configLoader;

    public void handleMessage(String topic, String jsonMessage) {
        GenericServiceConfig config = configLoader.getServiceConfigMap().get("password-reset");
        // Now use `config.getIncoming()` and validate
    }

    

}
