package com.praveen.kafka.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.praveen.kafka.model.GenericServiceConfig;
import com.praveen.kafka.model.RootConfig;
import jakarta.annotation.PostConstruct;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.util.Map;

@Component
@Getter
@Slf4j
public class JsonConfigLoader {

    private Map<String, GenericServiceConfig> serviceConfigMap;

    @PostConstruct
    public void loadConfig() {
        try {
            ObjectMapper mapper = new ObjectMapper();
            InputStream inputStream = getClass().getClassLoader().getResourceAsStream("config.json");
            RootConfig root = mapper.readValue(inputStream, RootConfig.class);
            this.serviceConfigMap = root.getServices();
            log.info("Loaded Service Config Map {}", this.serviceConfigMap);
        } catch (Exception e) {
            throw new RuntimeException("Failed to load config.json", e);
        }
    }
}
