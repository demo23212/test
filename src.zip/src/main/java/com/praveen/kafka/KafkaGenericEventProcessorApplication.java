package com.praveen.kafka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaGenericEventProcessorApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkaGenericEventProcessorApplication.class, args);
	}

}
