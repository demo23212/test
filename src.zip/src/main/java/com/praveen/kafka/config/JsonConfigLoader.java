package com.praveen.kafka.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.praveen.kafka.model.GenericServiceConfig;
import com.praveen.kafka.model.RootConfig;
import jakarta.annotation.PostConstruct;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.util.Map;

/**
 * Component responsible for loading Kafka service configuration from a JSON file at application startup.
 * It reads a JSON file named {@code config.json} from the classpath and parses it into a map of
 * service names to {@link GenericServiceConfig} instances. This configuration is used to dynamically
 * manage Kafka topic validation and subscription logic.
 * The expected structure of the JSON should match the {@link RootConfig} class, where the
 * services are stored as a map.
 * @author Praveen
 */
@Getter
@Slf4j
@Component
public class JsonConfigLoader {

    /**
     * Holds the loaded service configuration mapped by topic name.
     */
    private Map<String, GenericServiceConfig> serviceConfigMap;

    /**
     * Loads the configuration from {@code config.json} into {@link #serviceConfigMap}.
     * This method is invoked automatically by the Spring container after the bean's construction.
     * It reads the configuration JSON from the classpath and parses it into Java objects using Jackson.
     *
     * @throws RuntimeException if the configuration file is missing or invalid
     */
    @PostConstruct
    public void loadConfig() {
        try {
            ObjectMapper mapper = new ObjectMapper();
            InputStream inputStream = getClass().getClassLoader().getResourceAsStream("config.json");
            RootConfig root = mapper.readValue(inputStream, RootConfig.class);
            this.serviceConfigMap = root.getServices();
            log.info("Loaded Service Config Map {}", this.serviceConfigMap);
        } catch (Exception e) {
            throw new RuntimeException("Failed to load config.json", e);
        }
    }
}
