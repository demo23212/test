package com.praveen.kafka.model;

import com.fasterxml.jackson.annotation.JsonProperty;


import java.util.List;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Outgoing {
    @JsonProperty("destination-type")
    private String destinationType;

    private List<Message> message;

}
