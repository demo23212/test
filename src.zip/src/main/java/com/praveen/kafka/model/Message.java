package com.praveen.kafka.model;

import lombok.*;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Message {
    private String att1;
    private String att2;
    private List<Property> properties;

}

