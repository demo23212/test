package com.praveen.kafka.model;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class GenericServiceConfig {
    private Incoming incoming;
    private Outgoing outgoing;

}
